package com.annexcloud.actions.order;

/**
 * The type Sales tracking annex cloud action.
 */
public class SalesTrackingAnnexCloudAction
{ /*
   * extends AbstractSimpleDecisionAction<OrderProcessModel> { private static final Logger LOG =
   * Logger.getLogger(SalesTrackingAnnexCloudAction.class); private AnnexCloudSalesTrackingService
   * annexCloudSalesTrackingService;
   * 
   * public AnnexCloudSalesTrackingService getAnnexCloudSalesTrackingService() { return annexCloudSalesTrackingService;
   * }
   * 
   * public void setAnnexCloudSalesTrackingService(AnnexCloudSalesTrackingService annexCloudSalesTrackingService) {
   * this.annexCloudSalesTrackingService = annexCloudSalesTrackingService; }
   * 
   * @Override public Transition executeAction(OrderProcessModel orderProcessModel) throws RetryLaterException,
   * Exception { final OrderModel order = orderProcessModel.getOrder(); if (order == null) {
   * LOG.error("Missing the order, exiting the process"); return Transition.NOK; } Transition status= Transition.NOK;
   * String response=getAnnexCloudSalesTrackingService().sendSalesTrackingData(order); if(response.length()>0) status=
   * Transition.OK; return status; }
   */

}
