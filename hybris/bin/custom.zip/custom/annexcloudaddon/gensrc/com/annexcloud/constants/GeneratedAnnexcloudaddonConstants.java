/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 22-Jul-2021, 2:28:03 PM                     ---
 * ----------------------------------------------------------------
 */
package com.annexcloud.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated(since = "ages", forRemoval = false)
@SuppressWarnings({"unused","cast"})
public class GeneratedAnnexcloudaddonConstants
{
	public static final String EXTENSIONNAME = "annexcloudaddon";
	public static class TC
	{
		public static final String ANNEXCLOUDIMAGESLIDERHOMEPAGECOMPONENT = "AnnexCloudImageSliderHomePageComponent".intern();
	}
	public static class Attributes
	{
		public static class JspIncludeComponent
		{
			public static final String ACTIONNAME = "actionName".intern();
			public static final String PAGEID = "pageId".intern();
		}
	}
	
	protected GeneratedAnnexcloudaddonConstants()
	{
		// private constructor
	}
	
	
}
