package com.annexcloud.constants;

@SuppressWarnings({"deprecation","PMD","squid:CallToDeprecatedMethod"})
public class Annexcloudv3facadesConstants extends GeneratedAnnexcloudv3facadesConstants
{
	public static final String EXTENSIONNAME = "annexcloudv3facades";
	
	private Annexcloudv3facadesConstants()
	{
		//empty
	}
	
	
}
