/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 22-Jul-2021, 2:28:03 PM                     ---
 * ----------------------------------------------------------------
 */
package com.annexcloud.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated(since = "ages", forRemoval = false)
@SuppressWarnings({"unused","cast"})
public class GeneratedAnnexcloudbackofficeConstants
{
	public static final String EXTENSIONNAME = "annexcloudbackoffice";
	
	protected GeneratedAnnexcloudbackofficeConstants()
	{
		// private constructor
	}
	
	
}
