package com.annexcloud.dao;

import com.annexcloud.jalo.AnnexCloud;
import com.annexcloud.model.AnnexCloudModel;

import java.util.List;

public interface ACService {
    List<AnnexCloudModel> getSites();
}
