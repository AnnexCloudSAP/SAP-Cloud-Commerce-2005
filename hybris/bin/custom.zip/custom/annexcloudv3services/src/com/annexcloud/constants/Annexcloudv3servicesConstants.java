package com.annexcloud.constants;

@SuppressWarnings({"deprecation","PMD","squid:CallToDeprecatedMethod"})
public class Annexcloudv3servicesConstants extends GeneratedAnnexcloudv3servicesConstants
{
	public static final String EXTENSIONNAME = "annexcloudv3services";
	
	private Annexcloudv3servicesConstants()
	{
		//empty
	}
	
	
}
